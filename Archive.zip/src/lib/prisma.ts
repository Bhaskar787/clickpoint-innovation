import { PrismaClient } from "@/generated/prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import pg from "pg";

// Prevents exhausting the DB connection pool from hot-reloading
// PrismaClient in dev (Next.js reloads modules on every save).
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

const createPrismaClient = () => {
  const connectionString = process.env.DATABASE_URL;
  const pool = new pg.Pool({ connectionString });
  const adapter = new PrismaPg(pool);
  return new PrismaClient({
    adapter,
    log: process.env.NODE_ENV === "development" ? ["error", "warn"] : ["error"],
  });
};

const getPrisma = () => {
  const existing = globalForPrisma.prisma;
  // If an existing cached instance is missing new models, recreate client
  if (existing && (existing as any).servicesPage && (existing as any).aboutPage) {
    return existing;
  }
  const client = createPrismaClient();
  if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = client;
  return client;
};

export const prisma = getPrisma();
